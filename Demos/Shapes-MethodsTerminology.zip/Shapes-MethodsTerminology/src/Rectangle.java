public class Rectangle {
    //1.Attributes:
    int shapeLength;
    int shapeWidth;

    //2. Constructors:


    //3.Methods
    public int calcArea(int length, int width) {
        //Body of the method OR Method's Implementation
        return length * width;
    }



}
